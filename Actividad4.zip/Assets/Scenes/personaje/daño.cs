using UnityEngine;

public class daño : MonoBehaviour
{
   public Transform attackPoint; // El punto desde donde el jugador ataca
    public float attackRange = 0.5f; // El rango del ataque (el tamaño del área)
    public int attackDamage = 25; // El daño que inflige el ataque

    public LayerMask enemyLayers; // Capa que determina qué objetos se consideran enemigos

    void Update()
    {
        // Detecta si se presiona la tecla de ataque (puedes cambiar "Fire1" por tu input deseado)
        if (Input.GetButtonDown("Fire1"))
        {
            Attack();
        }
    }

    void Attack()
    {
        // Dibuja un círculo alrededor del punto de ataque para detectar enemigos
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayers);

        // Aplica daño a todos los enemigos detectados
        foreach (Collider2D enemy in hitEnemies)
        {
            enemy.GetComponent<Enemy>().TakeDamage(attackDamage); // Llama a la función de daño en el enemigo
            Debug.Log("Golpeaste al enemigo: " + enemy.name);
        }
    }

    // Visualiza el área de ataque en la escena para ajustar el rango (opcional)
    void OnDrawGizmosSelected()
    {
        if (attackPoint == null)
            return;

        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(attackPoint.position, attackRange); // Dibuja el área de ataque
    }
}
