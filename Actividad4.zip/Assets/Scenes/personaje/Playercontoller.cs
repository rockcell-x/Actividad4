using UnityEngine;

public class Player : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey("left"))
        {
            gameObject.transform.Translate(-5f * Time.deltaTime, 0, 0);
            gameObject.GetComponent<Animator>().SetBool("Move", true);
            gameObject.GetComponent<SpriteRenderer>().flipX = true;
        }
        if (Input.GetKey("right"))
        {
            gameObject.transform.Translate(5f * Time.deltaTime, 0, 0);
            gameObject.GetComponent<Animator>().SetBool("Move", true);
            gameObject.GetComponent<SpriteRenderer>().flipX = false;
        }
         if (Input.GetKey("up"))
        {
            gameObject.transform.Translate(0, 5f * Time.deltaTime, 0);
            gameObject.GetComponent<Animator>().SetBool("Move", true);
        }
         if (Input.GetKey("down"))
        {
            gameObject.transform.Translate(0, -5f * Time.deltaTime, 0);
            gameObject.GetComponent<Animator>().SetBool("Move", true);
        }
        if (!Input.anyKey)
        {
            gameObject.GetComponent<Animator>().SetBool("Move", false);
        }
    }
}
