using UnityEngine;

public class acercar : MonoBehaviour
{
    public Transform player; // Referencia al transform del jugador
    public float followRange = 3f; // Radio de detección
    public float moveSpeed = 2f; // Velocidad de movimiento del enemigo

    private bool isPlayerInRange;

    void Update()
    {
        // Calcular la distancia entre el enemigo y el jugador
        float distanceToPlayer = Vector3.Distance(transform.position, player.position);

        // Si la distancia es menor o igual al rango de seguimiento
        if (distanceToPlayer <= followRange)
        {
            isPlayerInRange = true;
        }
        else
        {
            isPlayerInRange = false;
        }

        // Si el jugador está en rango, mover al enemigo hacia el jugador
        if (isPlayerInRange)
        {
            MoveTowardsPlayer();
        }
        if (distanceToPlayer > 0.5f) // Detenerse cuando esté a 0.5 unidades de distancia del jugador
{
    MoveTowardsPlayer();
}
    }

    // Función que mueve al enemigo hacia el jugador
    void MoveTowardsPlayer()
    {
        // Dirección hacia el jugador
        Vector3 direction = (player.position - transform.position).normalized;

        // Mover al enemigo hacia el jugador
        transform.position += direction * moveSpeed * Time.deltaTime;
    }

    // Visualizar el rango de seguimiento en la escena
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, followRange);
    }
 }